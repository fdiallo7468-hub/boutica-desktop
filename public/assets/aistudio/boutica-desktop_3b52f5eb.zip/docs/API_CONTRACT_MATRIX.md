# Matrice des contrats API — Boutica Desktop ↔ Boutica Cloud v2.1

**Sources réellement consultées** : `README.md`, `CHANGELOG.md`, `BOUTICA_V2_FINALIZATION_REPORT.md` du dépôt Cloud, et le
cahier des charges de la mission.
**Non consultés** (accès automatisé refusé) : contrôleurs, DTO, schéma Drizzle, `AUDIT_REPORT.md`, `src/main.ts`, `src/auth/auth.ts`.

Légende d'état :
- **Confirmé (doc)** : route et usage décrits par la documentation Cloud ; non relu dans le contrôleur/DTO.
- **Partiel** : route confirmée par la doc, mais paramètres/champs précis non vérifiés dans les DTO.
- **Non confirmé** : aucune mention dans la documentation Cloud lue.
- Aucune ligne n'est « confirmé dans le code » : les sources du Cloud n'ont pas pu être lues.

Conventions documentées (Cloud) : pagination `{ data, page, pageSize, total }` ; montants en chaînes décimales ;
UUID ; `camelCase` ; `businessId` toujours déduit de la session (jamais du client) ; erreurs NestJS (`message` string ou tableau).
Tous les appels métier : `Authorization: Bearer <jeton de session Better Auth>` ajouté par le processus principal.
Les erreurs `401` déclenchent la déconnexion locale.

## Authentification (hors `/api/v1`) — gérée par le processus principal

| Méthode client | HTTP | Chemin | Corps / réponse | Pages | Réf. Cloud | État |
|---|---|---|---|---|---|---|
| `signIn` | POST | `/api/auth/sign-in/email` | `{email,password}` → `{token,user}` ; jeton lu dans l'en-tête `set-auth-token` (plugin bearer), repli `body.token` | Login | Better Auth ; README (Authentication) | Partiel : forme exacte de la réponse et signature du jeton à valider à l'exécution |
| `getSession` | GET | `/api/auth/get-session` | → `{user, session}` ou `null` ; exige `user.id` et `user.email` | App (démarrage), Login | Better Auth | Partiel |
| `signOut` | POST | `/api/auth/sign-out` | `{}` | Shell | Better Auth | Partiel |
| *(non implémenté)* | POST | `/api/auth/sign-up/email` | `{name,email,password,businessName,businessCurrency?}` | — | README | Confirmé (doc) mais **volontairement non exposé** (flux non implémenté) |
| *(non utilisé)* | GET | `/api/auth/token`, `/api/auth/jwks` | JWT portable | — | README | Non utilisé : le Desktop utilise le jeton de session Bearer |

## Santé

| Méthode client | HTTP | Chemin | Auth | Pages | Réf. Cloud | État |
|---|---|---|---|---|---|---|
| `checkHealth` | GET | `/health` | non | Login, Shell, Paramètres | `health.controller.ts` (doc) | Confirmé (doc). Ne prouve pas l'authentification. |

## Catalogue

| Méthode client | HTTP | Chemin | Paramètres / corps | Pages | État |
|---|---|---|---|---|---|
| `listProducts` | GET | `/api/v1/products` | `page,pageSize,search` (`search` : **non confirmé** ; la doc cite `category` et la pagination) | Produits | Partiel |
| `getProduct` | GET | `/api/v1/products/:id` | — | (non utilisé par une page) | Confirmé (doc) |
| `createProduct` | POST | `/api/v1/products` | `name, category?, brand?, description?` | Produits | Partiel |
| `updateProduct` | PATCH | `/api/v1/products/:id` | `name?, description?, category?, brand?, status?` | (non utilisé) | Partiel |
| `listProductVariants` | GET | `/api/v1/products/:id/variants` | `page,pageSize,search?` ; renvoie la quantité en stock | Produits | Confirmé (doc) |
| `addVariant` | POST | `/api/v1/products/:id/variants` | `sku,name,purchasePrice,sellingPrice,attributes?` ; invariant vente ≥ achat ; SKU unique par boutique | Produits | Partiel |
| `updateVariant` | PATCH | `/api/v1/products/:id/variants/:variantId` | champs partiels | Produits | Confirmé (doc) |
| `listAllVariants` | GET | `/api/v1/variants` | `search` (documenté), `page,pageSize` | POS, Stocks, Achats, Retours, Historique | Confirmé (doc) ; plafond de `pageSize` non vérifié |

## Stocks

| Méthode client | HTTP | Chemin | Corps | Pages | État |
|---|---|---|---|---|---|
| `getStock` | GET | `/api/v1/inventory/:variantId` | — | (non utilisé) | Confirmé (doc) |
| `adjustStock` | POST | `/api/v1/inventory/:variantId/adjust` | `{quantity, note?}` — quantité **cible absolue** (cahier des charges ; non relu dans le DTO) | Stocks | Partiel |

## Ventes

| Méthode client | HTTP | Chemin | Paramètres / corps | Pages | État |
|---|---|---|---|---|---|
| `listSales` | GET | `/api/v1/sales` | `from,to,customerId,page,pageSize` (format des dates non vérifié) | Historique, Clients, Retours | Confirmé (doc) |
| `getSale` | GET | `/api/v1/sales/:id` | — → vente + `items` | Historique, POS (reçu), Retours | Confirmé (doc) |
| `createSale` | POST | `/api/v1/sales` | `{customerId?, discount?, items:[{variantId,quantity}]}` ; header `Idempotency-Key` (rejeu = même réponse ; clé réutilisée avec corps différent = 409) ; `variantId` uniques dans `items` ; prix fixés par le serveur ; **pas de `paymentMethod`** | POS | Partiel : type exact de `discount` (nombre vs chaîne) non vérifié |

## Achats

| Méthode client | HTTP | Chemin | Paramètres / corps | Pages | État |
|---|---|---|---|---|---|
| `listPurchases` | GET | `/api/v1/purchases` | `from,to,supplierId,page,pageSize` | Achats | Confirmé (doc) |
| `getPurchase` | GET | `/api/v1/purchases/:id` | — | (non utilisé) | Confirmé (doc) |
| `receivePurchase` | POST | `/api/v1/purchases/receive` | `{supplierId?, items:[{variantId,quantity,unitPrice}]}` + `Idempotency-Key` ; `supplierId` doit appartenir à la boutique (400 sinon) | Achats | Partiel |

## Retours

| Méthode client | HTTP | Chemin | Paramètres / corps | Pages | État |
|---|---|---|---|---|---|
| `listReturns` | GET | `/api/v1/returns` | `from,to,saleId,page,pageSize` | Retours | Confirmé (doc) |
| `getReturn` | GET | `/api/v1/returns/:id` | — | (non utilisé) | Confirmé (doc) |
| `createReturn` | POST | `/api/v1/returns` | `{saleId, reason?, items:[{saleItemId,quantity,condition?}]}` + `Idempotency-Key` ; `condition` ∈ `RESTOCK`/`DAMAGED` ; sur-retour refusé | Retours | Partiel |

## Clients, fournisseurs, dépenses

| Méthode client | HTTP | Chemin | Corps | Pages | État |
|---|---|---|---|---|---|
| `listCustomers` | GET | `/api/v1/customers` | `page,pageSize` (pas de `search` côté serveur : filtre local) | Clients, POS | Confirmé (doc) |
| `getCustomer` | GET | `/api/v1/customers/:id` | — | Historique (reçu) | Confirmé (doc) |
| `createCustomer` | POST | `/api/v1/customers` | `{name, phone?}` | Clients | Confirmé (doc) |
| *(absent)* | PATCH/DELETE | `/api/v1/customers/:id` | — | — | **Non disponible** (CHANGELOG : aucune modification/désactivation) |
| `listSuppliers` | GET | `/api/v1/suppliers` | `page,pageSize` | Fournisseurs, Achats | Confirmé (doc) |
| `createSupplier` | POST | `/api/v1/suppliers` | `{name, phone?}` | Fournisseurs | Confirmé (doc) |
| *(absent)* | PATCH/DELETE | `/api/v1/suppliers/:id` | — | — | **Non disponible** |
| `listExpenses` | GET | `/api/v1/expenses` | `page,pageSize` | Dépenses | Confirmé (doc) |
| `createExpense` | POST | `/api/v1/expenses` | `{category, description?, amount}` (règles de `CreateExpenseDto` et catégories **non vérifiées**) | Dépenses | Partiel |
| *(absent)* | PATCH/DELETE | `/api/v1/expenses/:id` | — | — | **Non disponible** |

## Rapports

| Méthode client | HTTP | Chemin | Paramètres | Pages | État |
|---|---|---|---|---|---|
| `getDashboardReport` | GET | `/api/v1/reports/dashboard` | `from,to` (confirmés par le cahier des charges), `lowStockThreshold` (**non confirmé**) ; `receivables` toujours `null` | Tableau de bord | Confirmé (doc) / Partiel (paramètres) |
| `downloadReport('sales/excel')` | GET | `/api/v1/reports/sales/excel` | `from,to` | Rapports, Tableau de bord | **Non confirmé** : absent de README, CHANGELOG et du rapport v2.1 (qui ne citent que `/reports/dashboard`) |
| `downloadReport('inventory/excel')` | GET | `/api/v1/reports/inventory/excel` | — | idem | **Non confirmé** |
| `downloadReport('sales/pdf')` | GET | `/api/v1/reports/sales/pdf` | `from,to` | idem | **Non confirmé** |
| `downloadReport('inventory/pdf')` | GET | `/api/v1/reports/inventory/pdf` | — | idem | **Non confirmé** |

Les boutons d'export restent présents ; si la route n'existe pas, l'utilisateur voit « Cet export n'est pas disponible sur le
serveur Boutica Cloud » (aucun fichier factice).

## Écarts connus entre le modèle client (`types/api.ts`) et le Cloud
À vérifier contre les DTO/contrôleurs : forme exacte de `Sale.status`, présence de `items` dans la réponse de création,
`Variant.quantity` (jointure stock), champs de `Product` (`imageUrl`), format des dates (`createdAt`), type de `discount`.
