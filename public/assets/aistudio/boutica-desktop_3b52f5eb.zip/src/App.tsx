import React, { useCallback, useEffect, useState } from 'react';
import { Toaster, toast } from 'sonner';
import { useUIStore } from './renderer/store/uiStore.ts';
import { apiClient } from './renderer/lib/api-client.ts';
import { DesktopShell } from './renderer/layouts/DesktopShell.tsx';
import { LoginPage } from './renderer/pages/LoginPage.tsx';
import { DashboardPage } from './renderer/pages/DashboardPage.tsx';
import { PosSalePage } from './renderer/pages/PosSalePage.tsx';
import { ProductsPage } from './renderer/pages/ProductsPage.tsx';
import { InventoryPage } from './renderer/pages/InventoryPage.tsx';
import { SalesHistoryPage } from './renderer/pages/SalesHistoryPage.tsx';
import { PurchasesPage } from './renderer/pages/PurchasesPage.tsx';
import { ReturnsPage } from './renderer/pages/ReturnsPage.tsx';
import { CustomersPage } from './renderer/pages/CustomersPage.tsx';
import { SuppliersPage } from './renderer/pages/SuppliersPage.tsx';
import { ExpensesPage } from './renderer/pages/ExpensesPage.tsx';
import { ReportsPage } from './renderer/pages/ReportsPage.tsx';
import { SettingsPage } from './renderer/pages/SettingsPage.tsx';
import { CommandPalette } from './renderer/components/ui/CommandPalette.tsx';
import { ReceiptModal } from './renderer/components/ui/ReceiptModal.tsx';

export default function App() {
  const { currentPage, session, setSession } = useUIStore();
  const [isInitializing, setIsInitializing] = useState(true);
  const [startupError, setStartupError] = useState<string | null>(null);

  const checkSession = useCallback(async () => {
    setIsInitializing(true);
    setStartupError(null);
    try {
      // La session ne provient QUE d'une réponse serveur valide (jamais d'une session fabriquée localement).
      setSession(await apiClient.getSession());
    } catch (err) {
      // Serveur injoignable : on n'invente pas de session et on ne déduit pas qu'elle est invalide.
      setSession(null);
      setStartupError(err instanceof Error ? err.message : 'Impossible de vérifier la session.');
    } finally {
      setIsInitializing(false);
    }
  }, [setSession]);

  useEffect(() => {
    void checkSession();
  }, [checkSession]);

  // 401 reçu par le processus principal => session expirée : retour à l'écran de connexion.
  useEffect(() => {
    return apiClient.onSessionExpired(() => {
      setSession(null);
      toast.error('Votre session a expiré. Veuillez vous reconnecter.');
    });
  }, [setSession]);

  if (isInitializing) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-[#FDFDFD]">
        <div className="w-10 h-10 border-3 border-[#9A050E] border-t-transparent rounded-full animate-spin mb-4" />
        <span className="text-xs font-semibold text-[#2B282C] tracking-wide">
          Chargement de Boutica Desktop...
        </span>
      </div>
    );
  }

  // Pas de session valide : aucune page métier n'est accessible
  if (!session) {
    return (
      <>
        <Toaster position="top-right" richColors />
        <LoginPage startupError={startupError} onRetry={checkSession} />
      </>
    );
  }

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'pos':
        return <PosSalePage />;
      case 'products':
        return <ProductsPage />;
      case 'inventory':
        return <InventoryPage />;
      case 'sales':
        return <SalesHistoryPage />;
      case 'purchases':
        return <PurchasesPage />;
      case 'returns':
        return <ReturnsPage />;
      case 'customers':
        return <CustomersPage />;
      case 'suppliers':
        return <SuppliersPage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'reports':
        return <ReportsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <DesktopShell>
      {renderActivePage()}
      <CommandPalette />
      <ReceiptModal />
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: '12px',
            fontFamily: 'Inter, sans-serif',
            fontSize: '13px',
          },
        }}
      />
    </DesktopShell>
  );
}
