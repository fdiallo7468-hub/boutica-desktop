import React, { useEffect, useState } from 'react';
import { Mail, Lock, LogIn, Store, AlertCircle } from 'lucide-react';
import { BouticaLogo } from '../components/ui/BouticaLogo.tsx';
import { Button } from '../components/ui/Button.tsx';
import { Input } from '../components/ui/Input.tsx';
import { apiClient } from '../lib/api-client.ts';
import { useUIStore } from '../store/uiStore.ts';
import { toast } from 'sonner';

export const LoginPage: React.FC<{ startupError?: string | null; onRetry?: () => void }> = ({ startupError, onRetry }) => {
  const { setSession, isBackendHealthy, setBackendHealthy } = useUIStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Disponibilité technique uniquement (/health) : ne prouve pas que l'utilisateur est authentifié.
  useEffect(() => {
    apiClient
      .checkHealth()
      .then(() => setBackendHealthy(true))
      .catch(() => setBackendHealthy(false));
  }, [setBackendHealthy]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Veuillez renseigner votre email et mot de passe.');
      return;
    }
    setError(null);
    setIsLoading(true);

    try {
      const res = await apiClient.signIn(email.trim(), password);
      setSession(res);
      toast.success('Connexion réussie à Boutica Cloud');
    } catch (err: any) {
      setError(err?.message || 'Identifiants invalides ou serveur indisponible.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#FDFDFD] p-6 relative">
      {/* Decorative Brand Accent Background */}
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#5F0203] via-[#9A050E] to-[#AA3035]" />

      <div className="w-full max-w-md bg-white rounded-[18px] border border-[#E5E2E3] shadow-[0_8px_28px_rgba(43,40,44,0.12)] p-8 flex flex-col items-center">
        {/* Logo */}
        <div className="mb-4">
          <BouticaLogo variant="app-icon" size="lg" />
        </div>

        <h1 className="text-xl font-bold text-[#2B282C] text-center">
          Bienvenue sur Boutica
        </h1>
        <p className="text-xs text-[#706C70] text-center mt-1 mb-6">
          Connectez-vous pour accéder à votre espace de gestion commerciale.
        </p>

        {/* Backend health status badge */}
        <div className="w-full mb-4 px-3 py-1.5 rounded-lg bg-[#F7F6F6] border border-[#E5E2E3] flex items-center justify-between text-xs text-[#706C70]">
          <span className="flex items-center gap-1.5">
            <Store className="w-3.5 h-3.5 text-[#9A050E]" />
            Boutica Cloud API
          </span>
          <span
            className={`font-semibold ${
              isBackendHealthy ? 'text-[#16804A]' : 'text-[#D99016]'
            }`}
          >
            {isBackendHealthy === null ? 'Vérification…' : isBackendHealthy ? 'Serveur joignable' : 'Serveur injoignable'}
          </span>
        </div>

        {startupError && !error && (
          <div className="w-full mb-4 p-3 rounded-[10px] bg-[#FFF4DF] border border-[#D99016]/30 text-xs text-[#995B00]">
            <p>{startupError}</p>
            {onRetry && (
              <button type="button" onClick={onRetry} className="underline font-semibold mt-1">
                Réessayer
              </button>
            )}
          </div>
        )}

        {error && (
          <div className="w-full mb-4 p-3 rounded-[10px] bg-[#FCEAEC] border border-[#C62828]/20 flex items-start gap-2.5 text-xs text-[#C62828]">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Erreur d'authentification</p>
              <p>{error}</p>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSignIn} className="w-full space-y-4">
          <Input
            label="Adresse e-mail"
            type="email"
            placeholder="exemple@boutica.ci"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            leftIcon={<Mail className="w-4 h-4" />}
          />

          <Input
            label="Mot de passe"
            type="password"
            placeholder="••••••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            leftIcon={<Lock className="w-4 h-4" />}
          />

          <Button
            type="submit"
            variant="primary"
            size="lg"
            isLoading={isLoading}
            className="w-full"
            leftIcon={<LogIn className="w-4 h-4" />}
          >
            Se connecter
          </Button>
        </form>

        <p className="text-[11px] text-[#706C70] text-center mt-6">
          Boutica Desktop — Développé par Fluo
        </p>
      </div>
    </div>
  );
};
