import React from 'react';

interface BouticaLogoProps {
  variant?: 'mark' | 'full' | 'app-icon';
  color?: 'brand' | 'white' | 'dark';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const BouticaLogo: React.FC<BouticaLogoProps> = ({
  variant = 'mark',
  color = 'brand',
  size = 'md',
  className = '',
}) => {
  const getDimensions = () => {
    switch (size) {
      case 'sm':
        return { markSize: 24, fullHeight: 28, textScale: 'text-base', subScale: 'text-[9px]' };
      case 'lg':
        return { markSize: 44, fullHeight: 48, textScale: 'text-2xl', subScale: 'text-xs' };
      case 'xl':
        return { markSize: 64, fullHeight: 68, textScale: 'text-4xl', subScale: 'text-sm' };
      case 'md':
      default:
        return { markSize: 32, fullHeight: 36, textScale: 'text-lg', subScale: 'text-[10px]' };
    }
  };

  const { markSize, textScale, subScale } = getDimensions();

  const getFillColor = () => {
    switch (color) {
      case 'white':
        return '#FFFFFF';
      case 'dark':
        return '#2B282C';
      case 'brand':
      default:
        return '#9A050E';
    }
  };

  const fillColor = getFillColor();

  // Precision vector SVG of the official Boutica "B" monogram
  const Monogram = (
    <svg
      width={markSize}
      height={markSize}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 transition-transform duration-200"
    >
      <path
        d="M28 14C23.5817 14 20 17.5817 20 22V78C20 82.4183 23.5817 86 28 86C32.4183 86 36 82.4183 36 78V58H60C73.2548 58 84 47.2548 84 34C84 22.9543 75.0457 14 64 14H28Z"
        fill={fillColor}
        fillRule="evenodd"
        clipRule="evenodd"
      />
      <path
        d="M36 28V44H60C65.5228 44 70 39.5228 70 34C70 28.4772 65.5228 24 60 24H36V28Z"
        fill={variant === 'app-icon' ? '#9A050E' : '#FDFDFD'}
      />
      <path
        d="M36 50V74H58C64.6274 74 70 68.6274 70 62C70 55.3726 64.6274 50 58 50H36Z"
        fill={fillColor}
      />
      <circle cx="58" cy="62" r="6" fill={variant === 'app-icon' ? '#9A050E' : '#FDFDFD'} />
    </svg>
  );

  if (variant === 'app-icon') {
    return (
      <div
        className={`flex items-center justify-center rounded-[14px] bg-[#9A050E] shadow-md p-1.5 ${className}`}
        style={{ width: markSize * 1.35, height: markSize * 1.35 }}
      >
        <svg
          width={markSize}
          height={markSize}
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M28 14C23.5817 14 20 17.5817 20 22V78C20 82.4183 23.5817 86 28 86C32.4183 86 36 82.4183 36 78V58H60C73.2548 58 84 47.2548 84 34C84 22.9543 75.0457 14 64 14H28Z"
            fill="#FFFFFF"
            fillRule="evenodd"
            clipRule="evenodd"
          />
          <path
            d="M36 28V44H60C65.5228 44 70 39.5228 70 34C70 28.4772 65.5228 24 60 24H36V28Z"
            fill="#9A050E"
          />
          <path
            d="M36 50V74H58C64.6274 74 70 68.6274 70 62C70 55.3726 64.6274 50 58 50H36Z"
            fill="#FFFFFF"
          />
          <circle cx="58" cy="62" r="6" fill="#9A050E" />
        </svg>
      </div>
    );
  }

  if (variant === 'full') {
    return (
      <div className={`flex items-center gap-2.5 ${className}`}>
        {Monogram}
        <div className="flex flex-col justify-center leading-tight">
          <span
            className={`font-bold tracking-tight uppercase ${textScale}`}
            style={{ color: color === 'white' ? '#FFFFFF' : '#2B282C' }}
          >
            BOUTICA
          </span>
          <span
            className={`font-medium tracking-normal text-[#706C70] ${subScale}`}
            style={{ color: color === 'white' ? 'rgba(255,255,255,0.75)' : '#706C70' }}
          >
            Gestion commerciale
          </span>
        </div>
      </div>
    );
  }

  return <div className={`inline-flex items-center ${className}`}>{Monogram}</div>;
};
