/**
 * Centralized typed API client for Boutica Cloud
 * Voir docs/API_CONTRACT_MATRIX.md pour l'état de vérification de chaque route.
 */

import type { ReportDownloadType } from '../types/desktop.ts';
import type {
  PaginatedResponse,
  UserSession,
  SaleItem,
  PurchaseItem,
  ReturnItem,
  Product,
  Variant,
  StockItem,
  Sale,
  Purchase,
  ReturnOrder,
  Customer,
  Supplier,
  Expense,
  DashboardReport,
  CreateProductInput,
  UpdateProductInput,
  AddVariantInput,
  UpdateVariantInput,
  AdjustStockInput,
  CreateSaleInput,
  ReceivePurchaseInput,
  CreateReturnInput,
  CreateCustomerInput,
  CreateSupplierInput,
  CreateExpenseInput,
} from '../types/api.ts';

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown
  ) {
    super(message);
    this.name = 'ApiError';
  }

  /** Serveur injoignable ou délai dépassé : le résultat d'une écriture est alors INCERTAIN. */
  get isNetworkError(): boolean {
    return this.status === 0;
  }
}

function bridge() {
  const b = typeof window !== 'undefined' ? window.bouticaDesktop : undefined;
  if (!b) {
    throw new ApiError(
      0,
      'Boutica Desktop doit être lancé dans l’application Electron (le pont sécurisé est indisponible).'
    );
  }
  return b;
}

type Query = Record<string, string | number | undefined | null>;

/**
 * Client de Boutica Cloud. Aucune requête réseau n'est émise par le renderer : tout passe par le
 * processus principal Electron, qui détient le jeton de session et applique les règles communes
 * (Bearer, délai, erreurs, 401 => session expirée).
 */
export class BouticaApiClient {
  private async request<T>(
    method: 'GET' | 'POST' | 'PATCH',
    path: string,
    opts: { query?: Query; body?: unknown; idempotencyKey?: string } = {}
  ): Promise<T> {
    const res = await bridge().api({ method, path, ...opts });
    if (!res.ok) {
      throw new ApiError(res.status, res.error ?? `Erreur serveur (${res.status})`, res.data);
    }
    return res.data as T;
  }

  // --- HEALTH ---
  // Indique seulement que le serveur répond ; ne prouve ni l'authentification ni l'autorisation.
  async checkHealth(): Promise<{ status: string; service?: string; timestamp?: string }> {
    return this.request('GET', '/health');
  }

  // --- AUTHENTICATION (Better Auth — géré par le processus principal) ---
  async signIn(email: string, password: string): Promise<UserSession> {
    const res = await bridge().auth.signIn(email, password);
    if (!res.ok) throw new ApiError(401, res.error);
    return res.session;
  }

  /** null = pas de session valide. Lève ApiError(0) si le serveur est injoignable (session conservée). */
  async getSession(): Promise<UserSession | null> {
    const res = await bridge().auth.getSession();
    if (!res.ok) throw new ApiError(res.network ? 0 : 500, res.error);
    return res.session;
  }

  async signOut(): Promise<{ serverConfirmed: boolean }> {
    return bridge().auth.signOut();
  }

  onSessionExpired(cb: () => void): () => void {
    return window.bouticaDesktop?.auth.onSessionExpired(cb) ?? (() => {});
  }

  async getApiBaseUrl(): Promise<string> {
    return bridge().config.getApiBaseUrl();
  }

  async setApiBaseUrl(url: string): Promise<string> {
    const res = await bridge().config.setApiBaseUrl(url);
    if (!res.ok) throw new ApiError(0, res.error);
    return res.url;
  }

  // --- CATALOG & PRODUCTS ---
  async listProducts(params?: { search?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<Product>> {
    return this.request('GET', '/api/v1/products', { query: params });
  }

  async getProduct(id: string): Promise<Product> {
    return this.request('GET', `/api/v1/products/${enc(id)}`);
  }

  async createProduct(data: CreateProductInput): Promise<Product> {
    return this.request('POST', '/api/v1/products', { body: data });
  }

  async updateProduct(id: string, data: UpdateProductInput): Promise<Product> {
    return this.request('PATCH', `/api/v1/products/${enc(id)}`, { body: data });
  }

  async listProductVariants(productId: string, params?: { search?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<Variant>> {
    return this.request('GET', `/api/v1/products/${enc(productId)}/variants`, { query: params });
  }

  async addVariant(productId: string, data: AddVariantInput): Promise<Variant> {
    return this.request('POST', `/api/v1/products/${enc(productId)}/variants`, { body: data });
  }

  async updateVariant(productId: string, variantId: string, data: UpdateVariantInput): Promise<Variant> {
    return this.request('PATCH', `/api/v1/products/${enc(productId)}/variants/${enc(variantId)}`, { body: data });
  }

  // Variantes de toute la boutique (recherche) — catalogue du POS, stocks, réceptions
  async listAllVariants(params?: { search?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<Variant>> {
    return this.request('GET', '/api/v1/variants', { query: params });
  }

  // --- INVENTORY ---
  async getStock(variantId: string): Promise<StockItem> {
    return this.request('GET', `/api/v1/inventory/${enc(variantId)}`);
  }

  /** `quantity` est la quantité CIBLE absolue (pas un delta). */
  async adjustStock(variantId: string, data: AdjustStockInput): Promise<StockItem> {
    return this.request('POST', `/api/v1/inventory/${enc(variantId)}/adjust`, { body: data });
  }

  // --- SALES ---
  async listSales(params?: { from?: string; to?: string; customerId?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<Sale>> {
    return this.request('GET', '/api/v1/sales', { query: params });
  }

  async getSale(id: string): Promise<Sale & { items: SaleItem[] }> {
    return this.request('GET', `/api/v1/sales/${enc(id)}`);
  }

  /** La clé d'idempotence est OBLIGATOIRE ici : l'appelant la conserve pour rejouer une tentative incertaine. */
  async createSale(data: CreateSaleInput, idempotencyKey: string): Promise<Sale> {
    return this.request('POST', '/api/v1/sales', { body: data, idempotencyKey });
  }

  // --- PURCHASES ---
  async listPurchases(params?: { from?: string; to?: string; supplierId?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<Purchase>> {
    return this.request('GET', '/api/v1/purchases', { query: params });
  }

  async getPurchase(id: string): Promise<Purchase & { items: PurchaseItem[] }> {
    return this.request('GET', `/api/v1/purchases/${enc(id)}`);
  }

  async receivePurchase(data: ReceivePurchaseInput, idempotencyKey: string): Promise<Purchase> {
    return this.request('POST', '/api/v1/purchases/receive', { body: data, idempotencyKey });
  }

  // --- RETURNS ---
  async listReturns(params?: { from?: string; to?: string; saleId?: string; page?: number; pageSize?: number }): Promise<PaginatedResponse<ReturnOrder>> {
    return this.request('GET', '/api/v1/returns', { query: params });
  }

  async getReturn(id: string): Promise<ReturnOrder & { items: ReturnItem[] }> {
    return this.request('GET', `/api/v1/returns/${enc(id)}`);
  }

  async createReturn(data: CreateReturnInput, idempotencyKey: string): Promise<ReturnOrder> {
    return this.request('POST', '/api/v1/returns', { body: data, idempotencyKey });
  }

  // --- CUSTOMERS --- (pas de modification/suppression côté Cloud)
  async listCustomers(params?: { page?: number; pageSize?: number }): Promise<PaginatedResponse<Customer>> {
    return this.request('GET', '/api/v1/customers', { query: params });
  }

  async getCustomer(id: string): Promise<Customer> {
    return this.request('GET', `/api/v1/customers/${enc(id)}`);
  }

  async createCustomer(data: CreateCustomerInput): Promise<Customer> {
    return this.request('POST', '/api/v1/customers', { body: data });
  }

  // --- SUPPLIERS --- (liste + création uniquement)
  async listSuppliers(params?: { page?: number; pageSize?: number }): Promise<PaginatedResponse<Supplier>> {
    return this.request('GET', '/api/v1/suppliers', { query: params });
  }

  async createSupplier(data: CreateSupplierInput): Promise<Supplier> {
    return this.request('POST', '/api/v1/suppliers', { body: data });
  }

  // --- EXPENSES --- (liste + création uniquement)
  async listExpenses(params?: { page?: number; pageSize?: number }): Promise<PaginatedResponse<Expense>> {
    return this.request('GET', '/api/v1/expenses', { query: params });
  }

  async createExpense(data: CreateExpenseInput): Promise<Expense> {
    return this.request('POST', '/api/v1/expenses', { body: data });
  }

  // --- REPORTS ---
  async getDashboardReport(params?: { from?: string; to?: string; lowStockThreshold?: number }): Promise<DashboardReport> {
    return this.request('GET', '/api/v1/reports/dashboard', { query: params });
  }

  /**
   * Exports binaires : téléchargés par le processus principal vers un fichier choisi par l'utilisateur.
   * Échoue proprement si le serveur répond par une erreur (ou si la route n'existe pas).
   */
  async downloadReport(
    type: ReportDownloadType,
    params?: { from?: string; to?: string }
  ): Promise<{ filePath: string } | { canceled: true }> {
    const res = await bridge().downloadReport(type, params);
    if (res.success && res.filePath) return { filePath: res.filePath };
    if (res.canceled) return { canceled: true };
    throw new ApiError(0, res.error ?? 'Échec du téléchargement du rapport');
  }
}

const enc = encodeURIComponent;

export const apiClient = new BouticaApiClient();
